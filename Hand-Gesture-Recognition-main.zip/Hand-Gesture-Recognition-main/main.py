import tabs
import test
import sys
def main():
    tabs.tabs()
    test.test()

if __name__ == "__main__":
    main()